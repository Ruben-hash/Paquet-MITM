#!/usr/bin/python3
# -*- coding: utf-8 -*-
version = str("1.0.0")
print("Bienvenue, vous utilisez le paquet MITM v"+version+" !")
print("Faite CTRL+C")
